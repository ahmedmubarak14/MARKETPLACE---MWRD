// Centralized URL configuration for all MWRD apps
// These URLs are used for cross-app navigation

// In development, apps run on different ports
// In production, these would be environment variables pointing to different domains

const isDev = typeof window !== 'undefined'
    ? window.location.hostname === 'localhost'
    : true;

export const APP_URLS = {
    // Admin Portal - for admin users only
    admin: isDev ? 'http://localhost:5001' : (process.env.ADMIN_URL || 'https://admin.mwrd.com'),

    // Landing Page - public facing
    landing: isDev ? 'http://localhost:5002' : (process.env.LANDING_URL || 'https://mwrd.com'),

    // Marketplace - for clients and suppliers
    marketplace: isDev ? 'http://localhost:5003' : (process.env.MARKETPLACE_URL || 'https://app.mwrd.com'),
};

// Helper functions for common navigation patterns
export const navigateTo = {
    login: () => `${APP_URLS.marketplace}/login`,
    adminLogin: () => `${APP_URLS.admin}/login`,
    landing: () => APP_URLS.landing,
    interest: () => `${APP_URLS.landing}/interest`,
    marketplace: () => APP_URLS.marketplace,
    admin: () => APP_URLS.admin,
};

export default APP_URLS;
