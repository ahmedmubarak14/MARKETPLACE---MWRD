// Join Request Service
// Handles CRUD operations for the gated registration flow

import { supabase } from '../lib/supabase';

export type JoinRequestStatus = 'PENDING' | 'CONTACTED' | 'APPROVED' | 'REJECTED';
export type RequestedRole = 'CLIENT' | 'SUPPLIER';

export interface JoinRequest {
  id: string;
  email: string;
  name: string;
  companyName: string;
  phone?: string;
  role: RequestedRole;
  description?: string;
  status: JoinRequestStatus;
  adminNotes?: string;
  processedBy?: string;
  processedAt?: string;
  createdUserId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateJoinRequestData {
  email: string;
  name: string;
  companyName: string;
  phone?: string;
  role: RequestedRole;
  description?: string;
}

// Map database record to JoinRequest type
function mapDbToJoinRequest(db: any): JoinRequest {
  return {
    id: db.id,
    email: db.email,
    name: db.name,
    companyName: db.company_name,
    phone: db.phone,
    role: db.role,
    description: db.description,
    status: db.status,
    adminNotes: db.admin_notes,
    processedBy: db.processed_by,
    processedAt: db.processed_at,
    createdUserId: db.created_user_id,
    createdAt: db.created_at,
    updatedAt: db.updated_at,
  };
}

// Submit a new join request (public, unauthenticated)
export async function submitJoinRequest(data: CreateJoinRequestData): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('join_requests')
      .insert({
        email: data.email,
        name: data.name,
        company_name: data.companyName,
        phone: data.phone || null,
        role: data.role,
        description: data.description || null,
        status: 'PENDING',
      });

    if (error) {
      if (error.code === '23505') {
        return { success: false, error: 'This email has already submitted a request' };
      }
      console.error('Submit join request error:', error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (err) {
    console.error('Submit join request exception:', err);
    return { success: false, error: 'An unexpected error occurred' };
  }
}

// Get all join requests (admin only)
export async function getJoinRequests(status?: JoinRequestStatus): Promise<JoinRequest[]> {
  try {
    let query = supabase
      .from('join_requests')
      .select('*')
      .order('created_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Get join requests error:', error);
      return [];
    }

    return (data || []).map(mapDbToJoinRequest);
  } catch (err) {
    console.error('Get join requests exception:', err);
    return [];
  }
}

// Get a single join request by ID
export async function getJoinRequestById(id: string): Promise<JoinRequest | null> {
  try {
    const { data, error } = await supabase
      .from('join_requests')
      .select('*')
      .eq('id', id)
      .single();

    if (error || !data) {
      return null;
    }

    return mapDbToJoinRequest(data);
  } catch (err) {
    console.error('Get join request by ID exception:', err);
    return null;
  }
}

// Update join request status (admin only)
export async function updateJoinRequestStatus(
  id: string,
  status: JoinRequestStatus,
  adminId: string,
  notes?: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const updateData: any = {
      status,
      processed_by: adminId,
      processed_at: new Date().toISOString(),
    };

    if (notes !== undefined) {
      updateData.admin_notes = notes;
    }

    const { error } = await supabase
      .from('join_requests')
      .update(updateData)
      .eq('id', id);

    if (error) {
      console.error('Update join request status error:', error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (err) {
    console.error('Update join request status exception:', err);
    return { success: false, error: 'An unexpected error occurred' };
  }
}

// Mark request as user account created
export async function markRequestAsCreated(
  id: string,
  createdUserId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('join_requests')
      .update({
        status: 'APPROVED',
        created_user_id: createdUserId,
        processed_at: new Date().toISOString(),
      })
      .eq('id', id);

    if (error) {
      console.error('Mark request as created error:', error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (err) {
    console.error('Mark request as created exception:', err);
    return { success: false, error: 'An unexpected error occurred' };
  }
}

// Get count of pending requests (for badge in sidebar)
export async function getPendingRequestsCount(): Promise<number> {
  try {
    const { count, error } = await supabase
      .from('join_requests')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'PENDING');

    if (error) {
      return 0;
    }

    return count || 0;
  } catch (err) {
    return 0;
  }
}

export const joinRequestService = {
  submitJoinRequest,
  getJoinRequests,
  getJoinRequestById,
  updateJoinRequestStatus,
  markRequestAsCreated,
  getPendingRequestsCount,
};

export default joinRequestService;
