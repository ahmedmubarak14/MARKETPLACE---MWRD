import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { I18nextProvider } from 'react-i18next';
import i18n from '@mwrd/shared/i18n';
import { UserRole } from '@mwrd/shared/types';
import { useStore } from '@mwrd/shared/store';
import { useToast } from '@mwrd/shared/utils';
import { APP_URLS } from '@mwrd/shared/config';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ToastContainer } from './components/ui/Toast';
import { Sidebar } from './components/Sidebar';
import { Login } from './pages/Login';
import { AdminPortal } from './pages/admin/AdminPortal';
import { LoadingSpinner } from './components/ui/LoadingSpinner';

// Admin App - Admin portal only
// Clients and Suppliers should use app.mwrd.com

const AdminContent = () => {
  const navigate = useNavigate();
  const { currentUser, isAuthenticated, isLoading, login, logout, initializeAuth } = useStore();
  const toast = useToast();
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Initialize auth on mount
  useEffect(() => {
    initializeAuth();
  }, [initializeAuth]);

  // Redirect non-admin users to marketplace
  useEffect(() => {
    if (isAuthenticated && currentUser && currentUser.role !== UserRole.ADMIN) {
      window.location.href = APP_URLS.marketplace;
    }
  }, [isAuthenticated, currentUser]);

  const handleLogin = async (email: string, password: string) => {
    const user = await login(email, password);
    if (user) {
      if (user.role !== UserRole.ADMIN) {
        toast.error('Admin access only. Redirecting to marketplace...');
        setTimeout(() => {
          window.location.href = APP_URLS.marketplace;
        }, 1500);
        return null;
      }
      setActiveTab('overview');
      toast.success(`Welcome back, ${user.name}!`);
      navigate('/app');
      return user.role;
    } else {
      toast.error('Invalid credentials');
      return null;
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/admin-login');
    toast.info('You have been logged out');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <LoadingSpinner size="lg" />
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/admin-login" element={
        <ErrorBoundary>
          <ToastContainer toasts={toast.toasts} onClose={toast.removeToast} />
          <Login onLogin={handleLogin} onBack={() => window.location.href = APP_URLS.landing} />
        </ErrorBoundary>
      } />

      <Route path="/app/*" element={
        isAuthenticated && currentUser?.role === UserRole.ADMIN ? (
          <ErrorBoundary>
            <ToastContainer toasts={toast.toasts} onClose={toast.removeToast} />
            <div className="flex min-h-screen w-full bg-[#f9fafb] font-sans text-gray-900">
              <Sidebar
                role={UserRole.ADMIN}
                activeTab={activeTab}
                onNavigate={setActiveTab}
                onLogout={handleLogout}
              />
              <main className="flex-1 overflow-y-auto bg-gray-50/50 min-w-0">
                <AdminPortal activeTab={activeTab} />
              </main>
            </div>
          </ErrorBoundary>
        ) : (
          <Navigate to="/admin-login" replace />
        )
      } />

      <Route path="/" element={<Navigate to={isAuthenticated && currentUser?.role === UserRole.ADMIN ? "/app" : "/admin-login"} replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

function App() {
  return (
    <I18nextProvider i18n={i18n}>
      <BrowserRouter>
        <AdminContent />
      </BrowserRouter>
    </I18nextProvider>
  );
}

export default App;
