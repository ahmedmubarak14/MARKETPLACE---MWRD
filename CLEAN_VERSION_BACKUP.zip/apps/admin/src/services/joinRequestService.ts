// Re-export services from shared package
export {
    getJoinRequests,
    updateJoinRequestStatus,
    submitJoinRequest,
    getJoinRequestById,
    markRequestAsCreated,
    getPendingRequestsCount,
    joinRequestService
} from '@mwrd/shared';
export type { JoinRequest, JoinRequestStatus, RequestedRole, CreateJoinRequestData } from '@mwrd/shared';
