import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 5001,
  },
  build: {
    outDir: 'dist',
  },
  optimizeDeps: {
    // Exclude shared package sub-paths from pre-bundling since they're local workspace packages
    exclude: [
      '@mwrd/shared',
      '@mwrd/shared/types',
      '@mwrd/shared/store',
      '@mwrd/shared/services',
      '@mwrd/shared/utils',
      '@mwrd/shared/config',
      '@mwrd/shared/i18n',
    ],
  },
});
