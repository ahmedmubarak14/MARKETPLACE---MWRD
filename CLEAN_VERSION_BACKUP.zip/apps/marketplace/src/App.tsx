import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { I18nextProvider } from 'react-i18next';
import i18n from '@mwrd/shared/i18n';
import { UserRole } from '@mwrd/shared/types';
import { useStore } from '@mwrd/shared/store';
import { useToast } from '@mwrd/shared/utils';
import { APP_URLS } from '@mwrd/shared/config';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ToastContainer } from './components/ui/Toast';
import { Sidebar } from './components/Sidebar';
import { Login } from './pages/Login';
import { ClientPortal } from './pages/client/ClientPortal';
import { SupplierPortal } from './pages/supplier/SupplierPortal';
import { LoadingSpinner } from './components/ui/LoadingSpinner';

// Marketplace App - Client and Supplier portals only
// Admin should use admin.mwrd.com

const MarketplaceContent = () => {
  const navigate = useNavigate();
  const { currentUser, isAuthenticated, isLoading, login, logout, initializeAuth } = useStore();
  const toast = useToast();
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Initialize auth on mount
  useEffect(() => {
    initializeAuth();
  }, [initializeAuth]);

  // Redirect admin users to admin portal
  useEffect(() => {
    if (isAuthenticated && currentUser?.role === UserRole.ADMIN) {
      window.location.href = APP_URLS.admin;
    }
  }, [isAuthenticated, currentUser]);

  const handleLogin = async (email: string, password: string) => {
    const user = await login(email, password);
    if (user) {
      if (user.role === UserRole.ADMIN) {
        // Redirect admins to admin portal
        window.location.href = APP_URLS.admin;
        return null;
      }
      if (user.role === UserRole.CLIENT) setActiveTab('dashboard');
      if (user.role === UserRole.SUPPLIER) setActiveTab('dashboard');
      toast.success(`Welcome back, ${user.name}!`);
      navigate('/app');
      return user.role;
    } else {
      toast.error('Invalid credentials');
      return null;
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
    toast.info('You have been logged out');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <LoadingSpinner size="lg" />
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={
        <ErrorBoundary>
          <ToastContainer toasts={toast.toasts} onClose={toast.removeToast} />
          <Login onLogin={handleLogin} onBack={() => window.location.href = APP_URLS.landing} />
        </ErrorBoundary>
      } />

      <Route path="/app/*" element={
        isAuthenticated && currentUser ? (
          <ErrorBoundary>
            <ToastContainer toasts={toast.toasts} onClose={toast.removeToast} />
            <div className="flex min-h-screen w-full bg-[#f9fafb] font-sans text-gray-900">
              <Sidebar
                role={currentUser.role}
                activeTab={activeTab}
                onNavigate={setActiveTab}
                onLogout={handleLogout}
              />
              <main className="flex-1 overflow-y-auto bg-gray-50/50 min-w-0">
                {currentUser.role === UserRole.CLIENT && <ClientPortal activeTab={activeTab} onNavigate={setActiveTab} />}
                {currentUser.role === UserRole.SUPPLIER && <SupplierPortal activeTab={activeTab} onNavigate={setActiveTab} />}
              </main>
            </div>
          </ErrorBoundary>
        ) : (
          <Navigate to="/login" replace />
        )
      } />

      <Route path="/" element={<Navigate to={isAuthenticated ? "/app" : "/login"} replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

function App() {
  return (
    <I18nextProvider i18n={i18n}>
      <BrowserRouter>
        <MarketplaceContent />
      </BrowserRouter>
    </I18nextProvider>
  );
}

export default App;
