// Re-export i18n from shared package
import { i18n } from '@mwrd/shared';
export default i18n;
