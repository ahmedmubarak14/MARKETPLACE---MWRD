import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { LanguageToggle } from '../components/LanguageToggle';
import { submitJoinRequest, RequestedRole } from '@mwrd/shared/services';

interface InterestFormProps {
    onBack: () => void;
    onNavigateToLogin: () => void;
}

export const InterestForm: React.FC<InterestFormProps> = ({ onBack, onNavigateToLogin }) => {
    const { t } = useTranslation();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [formData, setFormData] = useState({
        name: '',
        email: '',
        companyName: '',
        phone: '',
        role: '' as RequestedRole | '',
        description: '',
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        setError(null);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        setError(null);

        // Validation
        if (!formData.role) {
            setError('Please select a role');
            setIsSubmitting(false);
            return;
        }

        const result = await submitJoinRequest({
            name: formData.name,
            email: formData.email,
            companyName: formData.companyName,
            phone: formData.phone || undefined,
            role: formData.role as RequestedRole,
            description: formData.description || undefined,
        });

        setIsSubmitting(false);

        if (result.success) {
            setIsSuccess(true);
        } else {
            setError(result.error || 'Something went wrong. Please try again.');
        }
    };

    // Success state
    if (isSuccess) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-200 p-4 font-sans">
                <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-12 text-center animate-in zoom-in-95 duration-300">
                    <div className="size-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                        <span className="material-symbols-outlined text-green-600 text-4xl">check_circle</span>
                    </div>
                    <h1 className="text-2xl font-bold text-slate-900 mb-3">{t('interestForm.successTitle')}</h1>
                    <p className="text-slate-500 mb-8">
                        {t('interestForm.successMessage')}
                    </p>
                    <button
                        onClick={onBack}
                        className="w-full bg-[#0A2540] hover:bg-[#0A2540]/90 text-white font-bold py-3.5 rounded-lg transition-all"
                    >
                        {t('interestForm.backToHome')}
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-200 p-4 font-sans">
            <div className="bg-white rounded-3xl shadow-2xl flex overflow-hidden max-w-5xl w-full min-h-[700px] animate-in zoom-in-95 duration-300">

                {/* Form Side */}
                <div className="w-full md:w-1/2 p-8 lg:p-12 flex flex-col relative overflow-y-auto">
                    <div className="absolute top-6 end-6">
                        <LanguageToggle />
                    </div>

                    <button onClick={onBack} className="flex items-center gap-3 mb-8 mt-4 hover:opacity-80 transition-opacity cursor-pointer">
                        <div className="size-8 bg-[#0A2540] rounded-lg flex items-center justify-center text-white">
                            <svg className="size-5" fill="none" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
                                <path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor"></path>
                            </svg>
                        </div>
                        <span className="text-[#0A2540] text-2xl font-bold tracking-tight">{t('common.brandName')}</span>
                    </button>

                    <h1 className="text-2xl font-bold text-slate-900 mb-2">{t('interestForm.title')}</h1>
                    <p className="text-slate-500 mb-6 text-sm">
                        {t('interestForm.subtitle')}
                    </p>

                    {error && (
                        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex items-center gap-2">
                            <span className="material-symbols-outlined text-lg">error</span>
                            {error}
                        </div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-4 flex-1">
                        {/* Full Name */}
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">{t('interestForm.fullName')} *</label>
                            <input
                                type="text"
                                name="name"
                                value={formData.name}
                                onChange={handleChange}
                                required
                                placeholder={t('interestForm.fullNamePlaceholder')}
                                className="w-full px-4 py-3 rounded-lg border border-slate-200 text-slate-900 placeholder:text-slate-400 focus:ring-2 focus:ring-[#0A2540] focus:border-transparent outline-none transition-all"
                            />
                        </div>

                        {/* Email */}
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">{t('interestForm.businessEmail')} *</label>
                            <input
                                type="email"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                required
                                placeholder={t('interestForm.businessEmailPlaceholder')}
                                className="w-full px-4 py-3 rounded-lg border border-slate-200 text-slate-900 placeholder:text-slate-400 focus:ring-2 focus:ring-[#0A2540] focus:border-transparent outline-none transition-all"
                            />
                        </div>

                        {/* Company Name */}
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">{t('interestForm.companyName')} *</label>
                            <input
                                type="text"
                                name="companyName"
                                value={formData.companyName}
                                onChange={handleChange}
                                required
                                placeholder={t('interestForm.companyNamePlaceholder')}
                                className="w-full px-4 py-3 rounded-lg border border-slate-200 text-slate-900 placeholder:text-slate-400 focus:ring-2 focus:ring-[#0A2540] focus:border-transparent outline-none transition-all"
                            />
                        </div>

                        {/* Phone */}
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">{t('interestForm.phoneNumber')}</label>
                            <input
                                type="tel"
                                name="phone"
                                value={formData.phone}
                                onChange={handleChange}
                                placeholder={t('interestForm.phoneNumberPlaceholder')}
                                className="w-full px-4 py-3 rounded-lg border border-slate-200 text-slate-900 placeholder:text-slate-400 focus:ring-2 focus:ring-[#0A2540] focus:border-transparent outline-none transition-all"
                            />
                        </div>

                        {/* Role Selection */}
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">{t('interestForm.selectRole')} *</label>
                            <div className="grid grid-cols-2 gap-3">
                                <button
                                    type="button"
                                    onClick={() => setFormData(prev => ({ ...prev, role: 'CLIENT' }))}
                                    className={`p-4 rounded-lg border-2 text-left transition-all ${formData.role === 'CLIENT'
                                        ? 'border-[#0A2540] bg-[#0A2540]/5'
                                        : 'border-slate-200 hover:border-slate-300'
                                        }`}
                                >
                                    <span className="material-symbols-outlined text-2xl mb-1 text-[#0A2540]">shopping_bag</span>
                                    <div className="font-semibold text-slate-900">{t('interestForm.client')}</div>
                                    <div className="text-xs text-slate-500">{t('interestForm.clientDesc')}</div>
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setFormData(prev => ({ ...prev, role: 'SUPPLIER' }))}
                                    className={`p-4 rounded-lg border-2 text-left transition-all ${formData.role === 'SUPPLIER'
                                        ? 'border-[#0A2540] bg-[#0A2540]/5'
                                        : 'border-slate-200 hover:border-slate-300'
                                        }`}
                                >
                                    <span className="material-symbols-outlined text-2xl mb-1 text-[#0A2540]">inventory_2</span>
                                    <div className="font-semibold text-slate-900">{t('interestForm.supplier')}</div>
                                    <div className="text-xs text-slate-500">{t('interestForm.supplierDesc')}</div>
                                </button>
                            </div>
                        </div>

                        {/* Description */}
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">{t('interestForm.description')}</label>
                            <textarea
                                name="description"
                                value={formData.description}
                                onChange={handleChange}
                                rows={3}
                                placeholder={t('interestForm.descriptionPlaceholder')}
                                className="w-full px-4 py-3 rounded-lg border border-slate-200 text-slate-900 placeholder:text-slate-400 focus:ring-2 focus:ring-[#0A2540] focus:border-transparent outline-none transition-all resize-none"
                            />
                        </div>

                        {/* Submit Button */}
                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="w-full bg-[#0A2540] hover:bg-[#0A2540]/90 text-white font-bold py-3.5 rounded-lg transition-all shadow-lg shadow-slate-900/20 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                        >
                            {isSubmitting ? (
                                <>
                                    <span className="material-symbols-outlined animate-spin text-xl">progress_activity</span>
                                    {t('interestForm.submitting')}
                                </>
                            ) : (
                                <>
                                    {t('interestForm.submitRequest')}
                                    <span className="material-symbols-outlined text-xl rtl:rotate-180">arrow_forward</span>
                                </>
                            )}
                        </button>
                    </form>

                    <div className="mt-6 text-center">
                        <p className="text-slate-500 text-sm">
                            {t('interestForm.haveAccount')} <button onClick={onNavigateToLogin} className="text-blue-600 font-bold hover:underline">{t('interestForm.signIn')}</button>
                        </p>
                    </div>
                </div>

                {/* Right Side - Decorative */}
                <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-blue-50 to-blue-100 relative flex-col justify-center p-12 lg:p-16 overflow-hidden">
                    <div className="absolute inset-0 opacity-20">
                        <svg className="absolute top-0 right-0 w-full h-full" viewBox="0 0 400 400" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M350 50L400 80V140L350 170L300 140V80L350 50Z" stroke="#0A2540" strokeWidth="1" fill="none" opacity="0.5" />
                            <path d="M50 300L100 330V390L50 420L0 390V330L50 300Z" stroke="#0A2540" strokeWidth="1" fill="none" opacity="0.5" />
                            <path d="M200 200L250 230V290L200 320L150 290V230L200 200Z" stroke="#0A2540" strokeWidth="1" fill="none" opacity="0.3" />
                            <circle cx="350" cy="80" r="3" fill="#0A2540" opacity="0.5" />
                            <circle cx="50" cy="330" r="3" fill="#0A2540" opacity="0.5" />
                        </svg>
                    </div>

                    <div className="relative z-10 max-w-md">
                        <h2 className="text-3xl lg:text-4xl font-bold text-[#0A2540] mb-6 leading-tight">
                            {t('interestForm.heroTitle')}
                        </h2>
                        <div className="space-y-4">
                            <div className="flex items-start gap-3">
                                <span className="material-symbols-outlined text-blue-600 text-xl mt-0.5">check_circle</span>
                                <div>
                                    <div className="font-semibold text-[#0A2540]">{t('interestForm.verifiedPartners')}</div>
                                    <div className="text-sm text-slate-600">{t('interestForm.verifiedPartnersDesc')}</div>
                                </div>
                            </div>
                            <div className="flex items-start gap-3">
                                <span className="material-symbols-outlined text-blue-600 text-xl mt-0.5">check_circle</span>
                                <div>
                                    <div className="font-semibold text-[#0A2540]">{t('interestForm.competitivePricing')}</div>
                                    <div className="text-sm text-slate-600">{t('interestForm.competitivePricingDesc')}</div>
                                </div>
                            </div>
                            <div className="flex items-start gap-3">
                                <span className="material-symbols-outlined text-blue-600 text-xl mt-0.5">check_circle</span>
                                <div>
                                    <div className="font-semibold text-[#0A2540]">{t('interestForm.managedProcess')}</div>
                                    <div className="text-sm text-slate-600">{t('interestForm.managedProcessDesc')}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
