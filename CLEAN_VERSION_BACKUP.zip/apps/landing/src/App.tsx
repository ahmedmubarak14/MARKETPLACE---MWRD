import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { I18nextProvider } from 'react-i18next';
import i18n from '@mwrd/shared/i18n';
import { APP_URLS } from '@mwrd/shared/config';
import { Landing } from './pages/Landing';
import { InterestForm } from './pages/InterestForm';

// Wrapper to provide navigation functions to pages
const LandingPage = () => {
  const navigate = useNavigate();
  return (
    <Landing
      onNavigateToLogin={() => window.location.href = `${APP_URLS.marketplace}/login`}
      onNavigateToInterest={() => navigate('/interest')}
    />
  );
};

const InterestFormPage = () => {
  const navigate = useNavigate();
  return (
    <InterestForm
      onBack={() => navigate('/')}
      onNavigateToLogin={() => window.location.href = `${APP_URLS.marketplace}/login`}
    />
  );
};

function App() {
  return (
    <I18nextProvider i18n={i18n}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/interest" element={<InterestFormPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </I18nextProvider>
  );
}

export default App;
