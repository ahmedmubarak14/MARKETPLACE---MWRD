import React from 'react';
import { useTranslation } from 'react-i18next';

interface LanguageToggleProps {
  className?: string;
}

export const LanguageToggle: React.FC<LanguageToggleProps> = ({ className = '' }) => {
  const { i18n, t } = useTranslation();

  const toggleLanguage = () => {
    const newLang = i18n.language === 'ar' ? 'en' : 'ar';
    i18n.changeLanguage(newLang);
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = newLang;
  };

  return (
    <button
      onClick={toggleLanguage}
      className={`group flex items-center gap-2 px-4 py-2 rounded-full bg-white/90 backdrop-blur-sm border border-slate-200/60 shadow-sm hover:shadow-md hover:border-slate-300 hover:bg-white transition-all duration-300 text-sm font-semibold text-slate-600 hover:text-[#0A2540] ${className}`}
    >
      <span className="material-symbols-outlined text-[1.1rem] transition-transform group-hover:scale-110 duration-300">language</span>
      <span className="tracking-wide">{i18n.language === 'ar' ? 'English' : 'العربية'}</span>
    </button>
  );
};
